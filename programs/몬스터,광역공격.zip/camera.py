__author__ = 'user'
from pico2d import *

import game_framework
import main_state
# from character import Character
from enemy import Enemy

#
# class Camera:
#    def __init__(self):
#         x = 400
#         y = 300
#    def update(self):
#        pass
#    def draw(self,x,y):
#         pass
#


class Camera:
    def __init__(self):
        self.image = load_image('resource/grass.png')
        self.background = load_image('resource/stage1.png')
        self.plus = 0
        self.mid = 400
        self.x = 0

    def update(self):
        print("ddddd")
        self.image = load_image('resource/stage1.png')
    def draw(self):
        self.image.draw(400, 30)
        self.background.draw(400+self.plus,400)

