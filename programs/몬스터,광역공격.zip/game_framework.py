import time

class GameState:
    def __init__(self, state):
        self.enter = state.enter
        self.exit = state.exit
        self.pause = state.pause
        self.resume = state.resume
        self.handle_events = state.handle_events
        self.update = state.update
        self.draw = state.draw



class TestGameState:

    def __init__(self, name):
        self.name = name

    def enter(self):
        print("State [%s] Entered" % self.name)

    def exit(self):
        print("State [%s] Exited" % self.name)

    def pause(self):
        print("State [%s] Paused" % self.name)

    def resume(self):
        print("State [%s] Resumed" % self.name)

    def handle_events(self):
        print("State [%s] handle_events" % self.name)

    def update(self,frame_time):
        print("State [%s] update(%f)" % self.name,frame_time)

    def draw(self):
        print("State [%s] draw" % self.name)



running = None
stack = None


def change_state(state):
    global stack
    pop_state()
    stack.append(state)
    state.enter()



def push_state(state):
    global stack
    if (len(stack) > 0):
        stack[-1].pause()
    stack.append(state)
    state.enter()
    #state는 main_state 등 이름이다
    #date를 넣어주는 함수를만든다.
    #stack은 그 상태를너두는것.
    #필요한 데이터를 넣어준다. ex 다른씬간의 데이터공유
def chardata_init(state,job=0,body=0,eye=0,hair=0):
    global stack
    state.chardata_init(job,body,eye,hair)



def pop_state():
    global stack
    if (len(stack) > 0):
        # execute the current state's exit function
        stack[-1].exit()
        # remove the current state
        stack.pop()

    # execute resume function of the previous state
    if (len(stack) > 0):
        stack[-1].resume()



def quit():
    global running
    running = False


def run(start_state):
    global running, stack
    running = True
    stack = [start_state]
    start_state.enter()
    current_time=time.time()
    while (running):
        frame_time=time.time()-current_time
        current_time=current_time+frame_time
        stack[-1].handle_events()
        stack[-1].update(frame_time)
        stack[-1].draw()
    # repeatedly delete the top of the stack
    while (len(stack) > 0):
        stack[-1].exit()
        stack.pop()
def reset_time():
    global current_time
    current_time=time.clock()

def test_game_framework():
    start_state = TestGameState('StartState')
   # run(start_state)



if __name__ == '__main__':
    test_game_framework()