from pico2d import *

import game_framework
import main_state
# from character import Character
# from enemy import Enemy
from effect import Effect1
from effect import Effect2
from effect import Effect3
from camera import Camera
import random
__author__ = 'user'

player = None
grass = None
font = None
enemy1 = None
mop = None
camera1 = None
potion=[]

class Potion:
   image = None
   def __init__(self,x=0,y=0):
        self.potiontype=0
        self.x = x
        self.y = y
   def update(self):
       pass
   def get_bb(self):
        return  self.x +50, 0, self.x + 160, 600

   def draw(self,x,y):
       Potion.image = load_image("resource/item/potion.png")
       self.image.draw(self.x+x,self.y+y)


#이펙트2시작
class Effect2:
   image = None
   def __init__(self):
        self.frameSize = 20
        self.frame = 0
        self.x = -1300
        self.y = -1
        self.effect_count = 0
        self.delete = False
   def init(self,x,y,frameNum):
        self.x = x
        self.y = y
        self.frame = frameNum
   def update(self):
        self.frame = (self.frame+1) % self.frameSize
        # print(self.x)

   def get_bb(self):
        return  self.x +50, 0, self.x + 160, 600
       # print("충돌체크")

   def delete(self):
        pass
       # self.delete = True
   def draw(self,x,y):
       Effect2.image = load_image("resource/attack2/62_%d.png"%self.frame)
       self.image.draw(self.x+100,self.y+250)
       draw_rectangle(*self.get_bb())

#이펙트끝

#character시작
class Character:
   global effect1,effect2,effect3,effect11,effect_list,effect_list2,effect_list3
   global effects, grass,camera,attackCount
   camera = None
   image = None
   hpbar = None
   hpbar2 = None
   frameSize = 2
   jump = True
   gravity = -30
   jumpMove = 0
   LEFT_IDLE, RIGHT_IDLE, LEFT_RUN, RIGHT_RUN,LEFT_JUMP,RIGHT_JUMP,LEFT_ATTACK,RIGHT_ATTACK =7,6,5,4,3,2,1,0
   global plus
   attackCount = 0
   effect_list = [Effect2() for i in range(10)]
   effect_list2 = [Effect1() for i in range(10)]
   effect_list3 = [Effect3() for i in range(10)]




   attack_frame = 0
   global Attack1,Attack2,Attack3
   Attack1 = False
   Attack2 = False
   Attack3 = False

   def __init__(self):
        self.potioncount=0
        self.total_frame=0.0
        self.x, self.y = 400, 90
        self.frame = random.randint(0, 1)
        self.state = self.LEFT_IDLE
        self.jumpPlus = 1
        self.jump = True
        self.gravity = 10
        self.attack_frame = 0
        if Character.image == None:
            Character.image = load_image('resource/character_sheet.png')
        self.camera = Camera()
        self.Move = False
        self.fullhp=1000
        self.hp = 1000
   def handle_event(self, event):
        global effects,effect1,effect3,effect2

        global Attack1,Attack2,Attack3,attackCount,effect_count

        if(event.type, event.key) == (SDL_KEYDOWN, SDLK_LEFT):
            if self.state in (self.RIGHT_IDLE, self.LEFT_IDLE,self.RIGHT_RUN):
                self.state = self.LEFT_RUN
        elif(event.type, event.key) == (SDL_KEYDOWN,SDLK_RIGHT):
            if self.state in (self.RIGHT_IDLE, self.LEFT_IDLE,self.LEFT_RUN):
                self.state = self.RIGHT_RUN
        elif(event.type,event.key)==(SDL_KEYDOWN,SDLK_1):
            if self.potioncount>0:
                self.potioncount=self.potioncount-1
                self.hp=self.hp+100
        # # 점프
        # elif(event.type, event.key) == (SDL_KEYDOWN,SDLK_SPACE):
        #         if self.state in (self.RIGHT_IDLE,self.RIGHT_RUN,):
        #             self.state = self.RIGHT_JUMP
        #             self.jumpMove = 5
        #             self.frameSize = 1
        #         if self.statef in (self.LEFT_IDLE,self.LEFT_RUN):
        #             self.state = self.LEFT_JUMP
        #             self.jumpMove = -5
        #             self.frameSize = 1

         # 공격1
        elif(event.type, event.key) == (SDL_KEYDOWN, SDLK_a):
            attackCount = 0
            if self.state in (self.RIGHT_IDLE,self.RIGHT_RUN):
                effect_list2[0].init(self.x-200 + self.plus, self.y-15,0)
                self.state = self.RIGHT_ATTACK
                self.frameSize = 7
                self.frame = 0
                Attack1 = True
                self.attack_frame = 0
                count = 0

            if self.state in (self.LEFT_IDLE,self.LEFT_RUN):
                self.state = self.LEFT_ATTACK
                self.frameSize = 7
                self.frame = 0
                Attack1 = True
                self.attack_frame = 0
                count = 0
                effect_list2[0].init(self.x-200 + self.plus, self.y-15,0)


       # 공격2
        elif(event.type, event.key) == (SDL_KEYDOWN, SDLK_z):
            attackCount = 0
            if self.state in (self.RIGHT_IDLE,self.RIGHT_RUN):
                self.state = self.RIGHT_ATTACK
                self.frameSize = 7
                self.frame = 0
                Attack2 = True
                self.attack_frame = 0
                count = 0
                # for effects in effect2:
                effect_list[0].init(self.x+70+self.plus, self.y-15,0)



            if self.state in (self.LEFT_IDLE,self.LEFT_RUN):
                self.state = self.LEFT_ATTACK
                self.frameSize = 7
                self.frame = 0
                Attack2 = True
                self.attack_frame = 0
                count = 0
                # for effects in effect2:
                effect_list[0].init(self.x-200 + self.plus, self.y-15,0)

        # 공격3
        elif(event.type, event.key) == (SDL_KEYDOWN, SDLK_x):
            if self.state in (self.RIGHT_IDLE,self.RIGHT_RUN):
                self.state = self.RIGHT_ATTACK
                self.frameSize = 7
                self.frame = 0
                Attack3 = True
                self.attack_frame = 0
                count = 0
                effect_list3[0].init(self.x+self.plus,self.y,0)
            if self.state in (self.LEFT_IDLE,self.LEFT_RUN):
                self.state = self.LEFT_ATTACK
                self.frameSize = 7
                self.frame = 0
                Attack3 = True
                self.attack_frame = 0
                count = 0
                effect_list3[0].init(self.x+self.plus,self.y,0)


        elif(event.type, event.key) == (SDL_KEYUP, SDLK_LEFT):
            if self.state in (self.LEFT_RUN,):
                self.state = self.LEFT_IDLE
                self.frameSize = 2
        elif(event.type, event.key) == (SDL_KEYUP, SDLK_RIGHT):
            if self.state in (self.RIGHT_RUN,):
                self.state = self.RIGHT_IDLE
                self.frameSize = 2
        elif(event.type, event.key) == (SDL_KEYUP, SDLK_z) :
            if self.state in (self.RIGHT_ATTACK,):
                self.state = self.RIGHT_IDLE
                self.frameSize = 2
            if self.state in (self.LEFT_ATTACK,):
                self.state = self.LEFT_IDLE
                self.frameSize = 2
        elif(event.type, event.key) == (SDL_KEYUP, SDLK_a) :
            if self.state in (self.RIGHT_ATTACK,):
                self.state = self.RIGHT_IDLE
                self.frameSize = 2
            if self.state in (self.LEFT_ATTACK,):
                self.state = self.LEFT_IDLE
                self.frameSize = 2

        elif(event.type, event.key) == (SDL_KEYUP, SDLK_x) :
            if self.state in (self.RIGHT_ATTACK,):
                self.state = self.RIGHT_IDLE
                self.frameSize = 2
            if self.state in (self.LEFT_ATTACK,):
                self.state = self.LEFT_IDLE
                self.frameSize = 2


   def collide(a,b):
        global plus
        left_a, bottom_a, right_a, top_a = a.get_bb(plus)
        left_b, bottom_b, right_b, top_b = b.get_bb(plus)

        if(left_a > right_b):return False
        if(right_a < left_b):return False
        if(top_a < bottom_b):return False
        if(bottom_a > top_b):return False

        return True

   def get_bb(self,plus):
       return self.x - 25+plus, self.y - 50, self.x + 25+plus, self.y + 30

   def setx(self,plus):
       self.plus = plus
   def update(self,plus,frame_time):
        global Attack1,Attack2,Attack3
        global effects,effect1,effect3,effect2,effect_count
        self.total_frame=self.total_frame+frame_time
        # for effects in effect2:
        if(Attack2 == True):
                effect_list[0].update()
        if(Attack1 == True):
                effect_list2[0].update()
        if(Attack3 == True):
                effect_list3[0].update()
        if self.attack_frame > 15:
            Attack1 = False
            Attack2 = False
            Attack3 = False
        self.attack_frame = self.attack_frame+1

        if self.total_frame> 0.2:
            self.frame = (self.frame+1) % self.frameSize
            self.total_frame=0.0
        if self.state == self.RIGHT_RUN:
             self.frameSize = 3
             self.Move = True
             self.x = min(800,self.x+1.5)
        elif self.state == self.LEFT_RUN:
              self.Move = True
              self.frameSize = 3
              self.x = max(0,self.x-1.5)
        elif self.state == self.LEFT_IDLE:
              self.frameSize = 2
        elif self.state == self.RIGHT_IDLE:
              self.frameSize = 2
        #공격
        elif self.state == self.RIGHT_ATTACK:
            pass
            # effect.update()
        #점프
        elif self.state == self.RIGHT_JUMP:
            self.frameSize = 1
            self.x = self.x+self.jumpMove
            if(self.jump):
                self.y = self.y + self.gravity
                self.gravity = self.gravity -2
                if(self.gravity < -10):
                    self.jump = False
                    self.gravity = 10
                    self.state = self.RIGHT_IDLE
            else:
             self.jump = True
             self.frameSize = 1

        elif self.state == self.LEFT_JUMP:
            self.frameSize = 1
            self.x = self.x+self.jumpMove
            if(self.jump):
                self.y = self.y + self.gravity
                self.gravity = self.gravity -2
                if(self.gravity < -10):
                    self.jump = False
                    self.gravity = 10
                    self.state = self.LEFT_IDLE
            else:
             self.jump = True
             self.frameSize = 1
        Character.hpbar = load_image("resource/character_hp.png")
        Character.hpbar2 = load_image("resource/character_hp_stroke.png")
   def draw(self,plus):
        global Attack1,Attack2,Attack3
        global effects,effect1,effect3,effect2,effect_count
        self.hpbar2.draw(250,550)
        self.image.clip_draw(self.frame * 150, self.state * 150, 150, 150, self.x+plus, self.y)
        self.hpbar.clip_draw(0,0,250+50,40,250-100+25,550)
        # self.hpbar.draw(250,550)
        draw_rectangle(*self.get_bb(plus))
        # for effects in effect2:
        if(self.attack_frame <=15):
                if(Attack2 == True):
                    effect_list[0].draw(self.x,self.y)

        if(Attack1 == True):
            effect_list2[0].draw(self.x, self.y)
        if(Attack3 == True):
            effect_list3[0].draw(self.x, self.y)

           #캐릭터끝

           #적시작
class Enemy:
   image = None
   frameSize = 6
   LEFT_IDLE, RIGHT_IDLE, LEFT_RUN, RIGHT_RUN,LEFT_HIT,RIGHT_HIT,LEFT_DIE,RIGHT_DIE =7,6,5,4,3,2,1,0

   def __init__(self):
        self.effectonecount=0.0
        self.total_frame=0.0
        self.frame_time = 0
        self.x, self.y = random.randint(100, 700), 90
        self.startx = self.x
        self.frame = random.randint(0, 4)
        self.state = self.LEFT_RUN
        if Enemy.image == None:
            Enemy.image = load_image('resource/monster1.png')
        self.dir =1
        self.randNum = random.randint(10,150)
        self.plus = 0
        self.hitCount = 0
        self.demege = 0
        self.ticCount = 0
        self.HP = 1000
   def setx(self,plus):
       self.plus = plus

   def demage(self,damage,ticCount):

        if self.effectonecount<=0.0:
            self.demege = damage
            self.ticCount = ticCount
            self.HP = self.HP - self.demege
            self.effectonecount=0.5

        print(self.ticCount)
   def setstate(self,a,hitcount):
       self.state = a
       self.hitCount = hitcount

   def update(self,frame_time):
      #  if(self.ticCount>0):
      #      self.ticCount-=1
        if self.effectonecount>0.0:
            self.effectonecount=self.effectonecount-frame_time
        self.total_frame=self.total_frame+frame_time

        if self.total_frame> 0.2:
            self.frame = (self.frame+1) % self.frameSize
            # self.ticCount += 1
            self.total_frame=0.0


        if(self.x > self.startx + self.randNum):
            self.dir = -1
        elif(self.x < self.startx - self.randNum):
            self.dir = 1
        if(self.state == self.LEFT_HIT):
            self.frameSize = 1
            self.hitCount = self.hitCount+1
            if(self.hitCount > 20):
                self.state = self.LEFT_RUN
        else:
            self.frameSize = 6

   def draw(self):
        # self.x = self.x+x
        self.image.clip_draw(self.frame * 150, self.state * 150, 150, 150, self.x+self.plus, self.y)
        draw_rectangle(*self.get_bb(self.plus))
   # 충돌박스좌표 리턴
   def get_bb(self,plus):
       return  self.x - 40+plus, self.y - 40, self.x + 40+plus, self.y + 40


#적끝

#state1
def enter():
   global player,grass,effect_list2
   global enemy1,mop,camera1,plus,mid,x,potion
   player = Character()
   grass = Grass()
   mop = [Enemy() for i in range(10)]
   camera1 = Camera()
   plus = 0
   mid = 400
   x = 0
   global state
   global attackCount
   attackCount = 0
   potion.append(Potion())
def exit():
    global player,grass,enemy1
    del(player)
    del(grass)
    del(enemy1)
def pause():
    pass

def resume():
    pass

def handle_events():
   events = get_events()
   global player
   for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif event.type == SDL_KEYDOWN  and event.key == SDLK_ESCAPE:
            game_framework.change_state(main_state)
        else :
            player.handle_event(event)
#충돌
def collide(a,b):
    left_a, bottom_a, right_a, top_a = a.get_bb(plus)
    left_b, bottom_b, right_b, top_b = b.get_bb()

    if(left_a > right_b):return False
    if(right_a < left_b):return False
    if(top_a < bottom_b):return False
    if(bottom_a > top_b):return False

    return True

def update(frame_time):
    global  mop1,plus,mid,player,removeCount,effect_count,attackCount,potion
    player.update(plus,frame_time)
  #  global  total_frame
  #  total_frame = total_frame+frame_time
    # print(attackCount)
    state = 3
    # camera1.update(Grass().plus,0)
    attackCount += 1
    if(attackCount > 5):
        # for effect_count in effect_list:
            for mop1 in mop:
                mop1.update(frame_time)
                if collide(mop1,effect_list2[0]):
                    mop.remove(mop1)
                    effect_list2.remove(effect_list2[0])

                if collide(mop1,effect_list[0]):
                    # mop.remove(mop1)
                    if(attackCount > 25):
                        effect_list.remove(effect_list[0])
                    mop1.setstate(3,0)
                    if(mop1.ticCount<1):
                        mop1.demage(400,0)
                        #    total_frame=0.0
                        print("hp",mop1.HP)
                        if(mop1.HP <= 0):
                            p=Potion(mop1.x,mop1.y)
                            mop.remove(mop1)
                            potion.append(p)



    grass.update()
    if player.x > mid:
        plus -= 1
        mid +=1
    if player.x < mid:
            # if plus !=0:
                plus +=1
                mid -=1
    for mop1 in mop:
        mop1.setx(plus)

    if(player.Move == True):
        player.setx(plus)

def draw():
    global  mop1,camera1,plus,potion
    clear_canvas()
    grass.draw(plus)
    #
    #1.draw()
    for mop1 in mop:
          mop1.draw()
    for potion1 in potion:
        potion1.draw(0,0)
    player.draw(plus)
    update_canvas()
  #  potion = Potion()
  #  potion.draw(100,100)

#state끝

class Grass:
    def __init__(self):
        self.image = load_image('resource/grass.png')
        self.background = load_image('resource/stage1.png')

    def update(self):
        pass
        # if player.x > self.mid:
        #     self.plus -= 0.5
        #     self.mid += 0.5
        # if player.x < self.mid:
        #     if self.plus !=0:
        #         self.plus +=0.5
        #         self.mid -=0.5
    def draw(self,plus):
        self.image.draw(400, 30)
        self.background.draw(400+plus,400)



